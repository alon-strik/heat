# please read the sdk API document in order to check the available widgets and the implemented action
# these widgets can be loaded or save using the loadWidget and saveWidget calls
# For saveWidget method, the data body of the request to be sent, can be read from a file, default value is input.txt.
# Exchange between FMG and application/script using this fmgJSON class could be save in using the saveRequests or unsaveRequests method.
# FortiManager SDK API allow to post several requests set as array list in the payload block. in this case requestor object 
# is used for widgets dependency . ( ie address onbjects used in a firewall policy)
# for simplicity, this is not implemented in this fmgJSON Class    
 
import string
import json
import urllib
import urllib2

class fmgJSON:
	""" FortiManager Class allowing to perform methods calls to the FortiManager device thru JSON"""
	__httpheaders=None
	__url=None
	__sessionid=None
	__wshelp={}
	__sessid=''
	__user=''
	__passw=''
	__adomid=-1
	__ppkgid=-1
	__saveinfile=None
	
	def __init__(self,fmgip,user,passw,secure=0):
		__url='http://'
		if secure:
			__url='https://'
		self.__url=__url+fmgip+'/portal/x/ptmgr'
		self.__httpheaders={"Content-Type": "application/x-www-form-urlencoded", "Accept": "*/*"}
		self.__user=user
		self.__passw=passw
		self.__sessionid=None	
		self.login()

	def __build_header_req(self):
		req={}
		head={}
		head['type']='request'
		head['sessionid']=self.__sessionid
		return head
		
	def setAdomid(self,adomid):
		self.__adomid=adomid
	
	def setPPkgid(self, id):
		self.__ppkgid=id
		
	def getPPkgid(self):
		return self.__ppkgid
		
	def getAdomid(self):
		return self.__adomid
	
	def saveRequests(self,filename):
		self.__saveinfile=filename
	
	def unsaveRequests(self):
		self.__saveinfile=None
		
	def __writefile(self,request,response):
		f=open(self.__saveinfile,'a')
		f.write('\n ---request--\n')
		json.dump(request,f,indent=4)
		f.write('\n ---response--\n')
		json.dump(response,f,indent=4)
		f.close()
				
				
	def __do_req_login(self,widget,action,instnb,usr,passw):
	
		req1=self.__build_header_req()
		data={}
		data['username']=usr
		data['password']=passw
		payhead={}
		payhead['action']=action
		payhead['widget']=widget
		payhead['instance']=instnb
		payhead1={}
		payhead1['header']=payhead
		payhead1['data']=data
		body={}
		body['header']=req1
		body['payload']=payhead1
		req=json.dumps(body)
		return req
		
	def  __do_req_logout(self):
		
		req1=self.__build_header_req()
		data=None		
		payhead={}
		payhead['action']='logout'
		payhead['widget']='layout'
		#payhead['instance']=instnb
		payhead1={}
		payhead1['header']=payhead
		payhead1['data']=data
		body={}
		body['header']=req1
		body['payload']=payhead1
		req=json.dumps(body)
		return req

	def __build_init_head(self,widget,action,sessid,inst,adomid=0):

		req1=self.__build_header_req()
		payhead={}
		payhead['action']=action
		payhead['widget']=widget
		payhead['instance']=inst
		if adomid > 0:
			payhead['adom']=adomid
		return req1,payhead


	def __do_initial_headerInstall(self,widget,action,sessid,inst,adomid,ppkgid):

		param1=self.__build_header_req()
		payhead={}
		payhead['action']=action
		payhead['widget']=widget
		payhead['instance']=inst
		if adomid >0:
			payhead['adom']=adomid
		id={}
		id['id']=ppkgid
		payhead['policy_pkg']=id
		return param1,payhead

		
		
	def __do_req_doInstall(self,widget,action,sessid,inst,adomid,pkgid):
		
		param1,param2=self.__do_initial_headerInstall(widget,action,sessid,inst,adomid,pkgid)
		body={}
		com={}
		com["command"]="install"
		body["header"]=param1
		pay={}
		pay['data']=com
		pay['header']=param2
		body['payload']=pay
		req=json.dumps(body)
		return req

	def __do_req_listpkgs(self,widget,action,sessid,inst,adomid):

		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req


	def doInstall(self,instance=3333):
		"""   perform installation, use switchPkg to set the adomid and pkgid or use setAdomid and setPPkgid before calling this method """

		head1=self.__do_req_doInstall('deploy','install',self.__sessionid,instance,self.__adomid,self.__ppkgid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		if res ==200:
			ret=obj['payload']['data']
			print 'Policy Package Install started'
			return ret
		else:
			print 'Policy Package Install start Error'
			print res
			return None
		
		
		

	def __do_req_listDynIntf(self,widget,action,sessid,inst,adomid):

		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req

	def __do_req_listUsers(self,widget,action,sessid,inst,adomid):

		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req


	def __do_req_listApplicationControl(self,widget,action,sessid,inst,adomid):

		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req

		
		
	def __do_req_getAdomInfo(self,widget,action,sessid,inst,adomid):
		
		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req
		
	def logout(self):
		head1=self.__do_req_logout()
		#print 
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		print obj
		if obj['header']['result']==200:
			print 'logout ok'
		self.__sessionid=None
		
	
	def login(self):
	
		head1=self.__do_req_login('layout','login',1,self.__user,self.__passw)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		if res ==200:
			self.__sessionid=obj['payload']['data']['sessionid']
			print 'login OK'
		else:
			print 'Error when login'
			print res
			print obj['payload']
			self.__sessionid=None
					
	def __do_req_listAddresses(self,widget,action,sessid,inst,adomid):

		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req

	def __do_req_listAddrGroups(self,widget,action,sessid,inst,adomid):

		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req

			
	def __do_req_listUsergroup(self,widget,action,sessid,inst,adomid):

		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req

	def __do_req_loadWidget(self,widget,action,sessid,inst,adomid):

		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		if widget=='firewallpolicy':
			id={}
			id['id']=self.__ppkgid
			p['policy_pkg']=id
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req
	
	def __do_req_saveWidget(self,widget,action,sessid,inst,adomid,obj1):

		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		body={}
		body['header']=head
		pay={}
		if widget=='firewallpolicy':
			id={}
			id['id']=self.__ppkgid
			p['policy_pkg']=id
		pay['header']=p
		pay['data']=obj1
		body['payload']=pay
		req=json.dumps(body)
		return req

	def __do_req_CheckInstall(self,widget,action,sessid,inst,adomid):


		head,p=self.__build_init_head(widget,action,sessid,inst,adomid)
		empty=[]
		body={}
		body['header']=head
		pay={}
		pay['header']=p
		pay['data']=empty
		body['payload']=pay
		req=json.dumps(body)
		return req


		
	def checkInstall(self,instance=3333):

		""" check installation status and device status tooo """
		
		head1=self.__do_req_CheckInstall('deploy','load',self.__sessionid,instance,self.__adomid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		if res ==200:
			ret=obj['payload']['data']
			return ret
		else:
			print 'Error in checkInstall request'
			ret=obj['payload']
			print ret
			return None

	
		
	def getAdomInfo(self,adomid=-1,instance=9999):
		if adomid<0:
			adomid=self.__adomid
		if adomid<0:
			print 'please select an adom using the setAdomid method'
			return None
		head1=self.__do_req_getAdomInfo('devicenavigator','load',self.__sessionid,instance,adomid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		if res ==200:
			ret=obj['payload']['data']
			#print 'request OK'
			return ret
		else:
			print 'Error in getAdomInfo request'
			print res
			return None
		
	def switchPkg(self,adomid,pkgid,instance=3333):
		
		ls=self.getAdomInfo(adomid)
		if ls != None:
			pklist=ls['ppkgs']
			found =0
			for pk in pklist:
				if pk['id']==pkgid:
					found=1
					target=pk
		if found == 0 :
			print 'package not found'
			return -1
		print 'Switching to Policy Package named:' ,' ',target['name']	
		# we suppose that we have only one device/Vdom per adom so we'll take the first one
		# not nice , to be rewritten. booooooo lazy jr !!!
		dev=ls['devices'][0]
		print dev
		head1=self._do_req_switchPkg('devicenavigator','switch',self.__sessionid,instance,adomid,pkgid,dev)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		if res ==200:
			#print 'request OK'
			self.__adomid=adomid
			self.__ppkgid=pkgid
			return 1
		else:
			print 'switchPkg request Error'
			print res
			self.__adomid=0
			self.__ppkgid=pkgid
			return -1

	
	
		
	def listPkgs(self,adomid=-1):
		""" list Policy Packages contained in an adom """
		
		if adomid<0:
			adomid=self.__adomid
		if adomid<0:
			print 'please select an adom using the setAdomid method'
			return None
		head1=self.__do_req_listpkgs('policypkgs','load',self.__sessionid,2,adomid)
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		if res ==200:
			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in listPkgs request'
			print res
			return None

	
			
	def listDynIntf(self,adomid=-1):
		""" list dynamic interfaces defined in the adom  """
		if adomid<0:
			adomid=self.__adomid
		if adomid<0:
			print 'please select an adom using the setAdomid method'
			return None		
		head1=self.__do_req_listDynIntf('dynintf','load',self.__sessionid,3,adomid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		if res ==200:
 			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None
	
	def listZones(self):
	
		head1=self._do_req_listZones('zones','load',self.__sessionid,3)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		#print res
		if res ==200:
 			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None
			
	def listUsers(self,adomid=-1):
		if adomid<0:
			adomid=self.__adomid
		if adomid<0:
			print 'please select an adom using the setAdomid method'
			return None		
		head1=self.__do_req_listUsers('users','load',self.__sessionid,3,adomid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		#print res
		if res ==200:
 			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None

			
	def listUsergroups(self,adomid=-1):
		if adomid<0:
			adomid=self.__adomid
		if adomid<0:
			print 'please select an adom using the setAdomid method'
			return None		
		head1=self.__do_req_listUsergroup('usergroups','load',self.__sessionid,3,adomid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		#print res
		if res ==200:
 			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None


	def listAddresses(self,adomid=-1):
		if adomid<0:
			adomid=self.__adomid
		if adomid<0:
			print 'please select an adom using the setAdomid method'
			return None		
		head1=self.__do_req_listAddresses('addresses','load',self.__sessionid,4,adomid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		#print res
		if res ==200:
 			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None


	def loadWidget(self,widget,action='load',adomid=-1):
		if adomid<0:
			adomid=self.__adomid
		if adomid<0:
			print 'please select an adom using the setAdomid method'
			return None
		if widget=='firewallpolicy':
			if self.__ppkgid < 0:
				print 'please set a valid policy package from this adom'
				return None
		head1=self.__do_req_loadWidget(widget,action,self.__sessionid,4,adomid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		if self.__saveinfile!=None:
			self.__writefile(json.loads(head1),obj)
		res=  obj['payload']['header']['result']
		#print res
		if res ==200:
 			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None

	def sendPayload(self,input='payload.txt'):

		try:
			f=open(input,'r')
			data=f.read()
			f.close()
		except Exception as e:
			print 'error reading input json file ' + input
			print e
			return None
		try:
			obj1=json.loads(data)
		except Exception as e:
			print 'invalid json object defined in ' + input
			print e
			return None
		head1=self.__build_header_req()
		payl1={}
		payl1['payload']=obj1
		packed={}
		packed['header']=head1
		packed['payload']=obj1
		req=json.dumps(packed)
		myreq=urllib2.Request(self.__url,req,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		obj=json.loads(s1)
		if self.__saveinfile!=None:
			self.__writefile(json.loads(req),obj)
		res=  obj['header']['result']
		#print res
		if res ==200:
 			ret=obj['payload']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None


				
	def saveWidget(self,widget,action='save',input='input.txt',adomid=-1,):
		if adomid<0:
			adomid=self.__adomid
		if adomid<0:
			print 'please set an Adom Id using the setAdomid method'
			return None	
		try:
			f=open(input,'r')
			data=f.read()
			f.close()
		except Exception as e:
			print 'error reading input json file ' + input
			print e
			return None
		try:
			obj1=json.loads(data)
		except Exception as e:
			print 'invalid json object defined in ' + input
			print e
			return None
		head1=self.__do_req_saveWidget(widget,action,self.__sessionid,4,adomid,obj1)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		if self.__saveinfile!=None:
			self.__writefile(json.loads(head1),obj)
		res=  obj['payload']['header']['result']
		#print res
		if res ==200:
 			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None
			
			
			
	def listAddrGroups(self,adomid=-1):
		if adomid<0:
			adomid=self.__adomid
		if adomid<0:
			print 'please select an adom using the setAdomid method'
			return None		
		head1=self.__do_req_listAddrGroups('addressgroups','load',self.__sessionid,4,adomid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		#print res
		if res ==200:
 			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None

			

	def listApplicationControl(self,adomid):

		head1=self.__do_req_listApplicationControl('applicationcontrol','load',self.__sessionid,4,adomid)
		#print
		#print head1
		#print
		myreq=urllib2.Request(self.__url,head1,self.__httpheaders)
		handler=urllib2.urlopen(myreq)
		s1=''	
		s1= handler.read()
		#print s1
		obj=json.loads(s1)
		res=  obj['payload']['header']['result']
		#print res
		if res ==200:
 			ret=obj['payload']['data']
			print 'request OK'
			return ret
		else:
			print 'Error in request'
			print res
			return None
		
